<?php
/**
 * Endpoint AJAX para Cesta (Carrinho).
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Cart.php';

header('Content-Type: application/json');

if (!User::isAuthenticated()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

$cart = new Cart($_SESSION['user_id']);
$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $list = $cart->list();
    $total = $cart->getTotal();
    $count = $cart->count();
    echo json_encode([
        'success' => true, 
        'data' => $list, 
        'total' => number_format($total, 2, ',', '.'), 
        'count' => $count
    ]);
} elseif ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_ids = $_POST['product_ids'] ?? [];

    if (!empty($product_ids) && is_array($product_ids)) {
        $successCount = 0;
        foreach ($product_ids as $pid) {
            if ($cart->add($pid)) {
                $successCount++;
            }
        }
        echo json_encode(['success' => true, 'message' => "$successCount produto(s) adicionado(s) à cesta"]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Nenhum produto selecionado']);
    }
} elseif ($action === 'remove' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'] ?? 0;

    if ($product_id > 0) {
        if ($cart->remove($product_id)) {
            echo json_encode(['success' => true, 'message' => 'Produto removido da cesta']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao remover produto']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'ID do produto inválido']);
    }
} elseif ($action === 'clear' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($cart->clear()) {
        echo json_encode(['success' => true, 'message' => 'Cesta limpa com sucesso']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao limpar cesta']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida']);
}
