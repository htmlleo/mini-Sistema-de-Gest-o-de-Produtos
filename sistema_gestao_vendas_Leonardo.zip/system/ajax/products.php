<?php
/**
 * Endpoint AJAX para Produtos.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Product.php';

header('Content-Type: application/json');

if (!User::isAuthenticated()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

$product = new Product();
$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $list = $product->list();
    echo json_encode(['success' => true, 'data' => $list]);
} elseif ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $price = $_POST['price'] ?? 0;
    $supplier_id = $_POST['supplier_id'] ?? 0;

    if ($name && $price > 0 && $supplier_id > 0) {
        if ($product->create($name, $price, $supplier_id)) {
            echo json_encode(['success' => true, 'message' => 'Produto cadastrado com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao cadastrar produto']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Preencha todos os campos corretamente']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida']);
}
