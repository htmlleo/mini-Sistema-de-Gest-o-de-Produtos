<?php
/**
 * Endpoint AJAX para Vendas (Finalização de Compra).
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Sale.php';

header('Content-Type: application/json');

if (!User::isAuthenticated()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

$sale = new Sale($_SESSION['user_id']);
$action = $_GET['action'] ?? '';

if ($action === 'finalize' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $sale->finalize();
    echo json_encode($result);
} elseif ($action === 'history') {
    $history = $sale->listHistory();
    echo json_encode(['success' => true, 'data' => $history]);
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida']);
}
