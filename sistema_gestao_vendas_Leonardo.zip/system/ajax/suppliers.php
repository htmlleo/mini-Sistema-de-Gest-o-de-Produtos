<?php
/**
 * Endpoint AJAX para Fornecedores.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

require_once '../classes/Database.php';
require_once '../classes/User.php';
require_once '../classes/Supplier.php';

header('Content-Type: application/json');

if (!User::isAuthenticated()) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

$supplier = new Supplier();
$action = $_GET['action'] ?? '';

if ($action === 'list') {
    $list = $supplier->list();
    echo json_encode(['success' => true, 'data' => $list]);
} elseif ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $contact = $_POST['contact'] ?? '';

    if ($name && $contact) {
        if ($supplier->create($name, $contact)) {
            echo json_encode(['success' => true, 'message' => 'Fornecedor cadastrado com sucesso']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao cadastrar fornecedor']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Preencha todos os campos corretamente']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida']);
}
