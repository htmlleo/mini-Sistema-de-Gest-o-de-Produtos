/**
 * Mini Sistema de Gestão — app.js
 * Gerencia a integração AJAX entre o front-end e o back-end.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

$(function () {

    /* ============================================================
       Utilitários: Notificações e Carregamento
       ============================================================ */
    function showAlert(message, type = 'success') {
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        $('#alert-container').html(alertHtml);
        setTimeout(() => $('.alert').alert('close'), 4000);
    }

    /* ============================================================
       ÁREA 1: CADASTRO (Produtos e Fornecedores)
       ============================================================ */
    $('#form-supplier').on('submit', function (e) {
        e.preventDefault();
        const data = $(this).serialize();
        $.post('ajax/suppliers.php?action=create', data, function (res) {
            if (res.success) {
                showAlert(res.message);
                $('#form-supplier')[0].reset();
                loadAllData(); // Atualiza Áreas 2 e 3
            } else {
                showAlert(res.message, 'danger');
            }
        });
    });

    $('#form-product').on('submit', function (e) {
        e.preventDefault();
        const data = $(this).serialize();
        $.post('ajax/products.php?action=create', data, function (res) {
            if (res.success) {
                showAlert(res.message);
                $('#form-product')[0].reset();
                loadAllData(); // Atualiza Áreas 2 e 3
            } else {
                showAlert(res.message, 'danger');
            }
        });
    });

    /* ============================================================
       ÁREA 2: ATUALIZAÇÃO AJAX (Listagem de Dados)
       ============================================================ */
    function loadAjaxLists() {
        // Listagem de Produtos
        $.get('ajax/products.php?action=list', function (res) {
            if (res.success) {
                let html = '';
                res.data.forEach(p => {
                    html += `<tr><td>${p.name}</td><td>R$ ${parseFloat(p.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td><td>${p.supplier_name}</td></tr>`;
                });
                $('#ajax-products-list').html(html);
            }
        });

        // Listagem de Fornecedores
        $.get('ajax/suppliers.php?action=list', function (res) {
            if (res.success) {
                let html = '';
                let options = '<option value="">Selecione um fornecedor</option>';
                res.data.forEach(s => {
                    html += `<tr><td>${s.name}</td><td>${s.contact}</td></tr>`;
                    options += `<option value="${s.id}">${s.name}</option>`;
                });
                $('#ajax-suppliers-list').html(html);
                $('#product-supplier-id').html(options); // Atualiza select da Área 1
            }
        });
    }

    /* ============================================================
       ÁREA 3: SELEÇÃO (Checkbox e Inclusão na Cesta)
       ============================================================ */
    function loadSelectionList() {
        $.get('ajax/products.php?action=list', function (res) {
            if (res.success) {
                let html = '';
                res.data.forEach(p => {
                    html += `
                        <tr>
                            <td class="text-center"><input type="checkbox" class="product-checkbox" value="${p.id}"></td>
                            <td>${p.name}</td>
                            <td>R$ ${parseFloat(p.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td>${p.supplier_name}</td>
                        </tr>
                    `;
                });
                $('#selection-products-list').html(html);
            }
        });
    }

    $('#btn-add-to-cart').on('click', function () {
        const selectedIds = [];
        $('.product-checkbox:checked').each(function () {
            selectedIds.push($(this).val());
        });

        if (selectedIds.length === 0) {
            showAlert('Selecione pelo menos um produto para incluir na cesta!', 'warning');
            return;
        }

        $.post('ajax/cart.php?action=add', { product_ids: selectedIds }, function (res) {
            if (res.success) {
                showAlert(res.message);
                $('.product-checkbox').prop('checked', false);
                loadCartArea(); // Atualiza Área 4
            } else {
                showAlert(res.message, 'danger');
            }
        });
    });

    /* ============================================================
       ÁREA 4: CESTA (Exibição e Resumo)
       ============================================================ */
    function loadCartArea() {
        $.get('ajax/cart.php?action=list', function (res) {
            if (res.success) {
                let html = '';
                res.data.forEach(item => {
                    html += `
                        <tr>
                            <td>${item.name}</td>
                            <td>R$ ${parseFloat(item.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td>${item.supplier_name}</td>
                            <td>
                                <button class="btn btn-sm btn-outline-danger btn-remove-cart" data-id="${item.id}">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
                $('#cart-items-list').html(html);
                $('#cart-total-value').text('R$ ' + res.total);
                $('#cart-total-items').text(res.count);
            }
        });
    }

    // Remover item da cesta
    $(document).on('click', '.btn-remove-cart', function () {
        const id = $(this).data('id');
        $.post('ajax/cart.php?action=remove', { product_id: id }, function (res) {
            if (res.success) {
                showAlert(res.message);
                loadCartArea();
            }
        });
    });

    // Limpar cesta
    $('#btn-clear-cart').on('click', function () {
        if (confirm('Deseja realmente limpar toda a cesta?')) {
            $.post('ajax/cart.php?action=clear', function (res) {
                if (res.success) {
                    showAlert(res.message);
                    loadCartArea();
                }
            });
        }
    });

    // FINALIZAR COMPRA (Venda)
    $('#btn-finalize-sale').on('click', function () {
        const totalItems = parseInt($('#cart-total-items').text());
        
        if (totalItems === 0) {
            showAlert('Sua cesta está vazia!', 'warning');
            return;
        }

        if (confirm('Deseja finalizar a compra de ' + totalItems + ' produto(s)?')) {
            $.post('ajax/sales.php?action=finalize', function (res) {
                if (res.success) {
                    showAlert('<strong>' + res.message + '</strong><br>Total: R$ ' + res.total + '<br>Pedido #' + res.sale_id, 'success');
                    loadCartArea(); // Atualiza Área 4 (limpa a cesta)
                } else {
                    showAlert(res.message, 'danger');
                }
            });
        }
    });

    /* ============================================================
       Inicialização Geral
       ============================================================ */
    function loadAllData() {
        loadAjaxLists();
        loadSelectionList();
        loadCartArea();
    }

    loadAllData();

});
