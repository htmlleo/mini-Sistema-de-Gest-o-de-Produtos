<?php
/**
 * Classe Cart — Gerencia a cesta de produtos (carrinho).
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

class Cart {
    private $db;
    private $user_id;

    public function __construct($user_id) {
        $this->db = Database::getInstance()->getConnection();
        $this->user_id = $user_id;
    }

    /**
     * Adiciona produtos à cesta do usuário (Área 3: Seleção Checkbox).
     * Garante apenas uma unidade de cada produto (UNIQUE KEY no banco).
     */
    public function add($product_id) {
        try {
            $stmt = $this->db->prepare("INSERT IGNORE INTO cart_items (user_id, product_id) VALUES (?, ?)");
            return $stmt->execute([$this->user_id, $product_id]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Remove um produto da cesta do usuário.
     */
    public function remove($product_id) {
        $stmt = $this->db->prepare("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?");
        return $stmt->execute([$this->user_id, $product_id]);
    }

    /**
     * Lista todos os itens na cesta do usuário com detalhes (Área 4: Exibição Cesta).
     */
    public function list() {
        $stmt = $this->db->prepare("
            SELECT p.id, p.name, p.price, s.name as supplier_name 
            FROM cart_items ci 
            JOIN products p ON ci.product_id = p.id 
            JOIN suppliers s ON p.supplier_id = s.id 
            WHERE ci.user_id = ? 
            ORDER BY ci.added_at DESC
        ");
        $stmt->execute([$this->user_id]);
        return $stmt->fetchAll();
    }

    /**
     * Calcula o valor total da cesta (Área 4: Resumo).
     */
    public function getTotal() {
        $stmt = $this->db->prepare("
            SELECT SUM(p.price) as total 
            FROM cart_items ci 
            JOIN products p ON ci.product_id = p.id 
            WHERE ci.user_id = ?
        ");
        $stmt->execute([$this->user_id]);
        $result = $stmt->fetch();
        return $result['total'] ?? 0.00;
    }

    /**
     * Conta o número de itens na cesta (Área 4: Resumo).
     */
    public function count() {
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM cart_items WHERE user_id = ?");
        $stmt->execute([$this->user_id]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    /**
     * Limpa toda a cesta do usuário.
     */
    public function clear() {
        $stmt = $this->db->prepare("DELETE FROM cart_items WHERE user_id = ?");
        return $stmt->execute([$this->user_id]);
    }
}
