<?php
/**
 * Classe Product — Gerencia produtos e relacionamento com fornecedores.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

class Product {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Cadastra um novo produto (Área 1: Cadastro).
     */
    public function create($name, $price, $supplier_id) {
        $stmt = $this->db->prepare("INSERT INTO products (name, price, supplier_id) VALUES (?, ?, ?)");
        return $stmt->execute([$name, $price, $supplier_id]);
    }

    /**
     * Lista todos os produtos com o nome do fornecedor (Área 2: AJAX Listagem).
     */
    public function list() {
        $stmt = $this->db->query("
            SELECT p.*, s.name as supplier_name 
            FROM products p 
            JOIN suppliers s ON p.supplier_id = s.id 
            ORDER BY p.name ASC
        ");
        return $stmt->fetchAll();
    }
}
