<?php
/**
 * Classe Sale — Gerencia a finalização da compra.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

class Sale {
    private $db;
    private $user_id;

    public function __construct($user_id) {
        $this->db = Database::getInstance()->getConnection();
        $this->user_id = $user_id;
    }

    /**
     * Finaliza a compra:
     * 1. Obtém itens da cesta
     * 2. Calcula o total
     * 3. Cria registro na tabela 'sales'
     * 4. Move itens para 'sale_items'
     * 5. Limpa a cesta
     */
    public function finalize() {
        try {
            $this->db->beginTransaction();

            // 1. Obter itens da cesta
            $stmt = $this->db->prepare("
                SELECT p.id, p.price 
                FROM cart_items ci 
                JOIN products p ON ci.product_id = p.id 
                WHERE ci.user_id = ?
            ");
            $stmt->execute([$this->user_id]);
            $items = $stmt->fetchAll();

            if (empty($items)) {
                throw new Exception("A cesta está vazia.");
            }

            // 2. Calcular total
            $total = 0;
            foreach ($items as $item) {
                $total += $item['price'];
            }

            // 3. Criar registro de venda
            $stmt = $this->db->prepare("INSERT INTO sales (user_id, total_value) VALUES (?, ?)");
            $stmt->execute([$this->user_id, $total]);
            $sale_id = $this->db->lastInsertId();

            // 4. Inserir itens da venda (histórico)
            $stmt = $this->db->prepare("INSERT INTO sale_items (sale_id, product_id, price_at_sale) VALUES (?, ?, ?)");
            foreach ($items as $item) {
                $stmt->execute([$sale_id, $item['id'], $item['price']]);
            }

            // 5. Limpar a cesta do usuário
            $stmt = $this->db->prepare("DELETE FROM cart_items WHERE user_id = ?");
            $stmt->execute([$this->user_id]);

            $this->db->commit();
            return [
                'success' => true, 
                'message' => 'Compra finalizada com sucesso!', 
                'sale_id' => $sale_id,
                'total' => number_format($total, 2, ',', '.')
            ];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Lista o histórico de vendas do usuário (Opcional para diferencial)
     */
    public function listHistory() {
        $stmt = $this->db->prepare("SELECT * FROM sales WHERE user_id = ? ORDER BY sale_date DESC");
        $stmt->execute([$this->user_id]);
        return $stmt->fetchAll();
    }
}
