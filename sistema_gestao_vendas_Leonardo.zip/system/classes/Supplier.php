<?php
/**
 * Classe Supplier — Gerencia fornecedores.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

class Supplier {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Cadastra um novo fornecedor.
     */
    public function create($name, $contact) {
        $stmt = $this->db->prepare("INSERT INTO suppliers (name, contact) VALUES (?, ?)");
        return $stmt->execute([$name, $contact]);
    }

    /**
     * Lista todos os fornecedores.
     */
    public function list() {
        $stmt = $this->db->query("SELECT * FROM suppliers ORDER BY name ASC");
        return $stmt->fetchAll();
    }
}
