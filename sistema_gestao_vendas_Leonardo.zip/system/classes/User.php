<?php
/**
 * Classe User — Gerencia usuários e autenticação.
 *
 * Desenvolvido por Leonardo Estevão Alves — RA: 00250458-1
 */

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Registra um novo usuário com hash SHA-256.
     */
    public function register($name, $email, $password) {
        $hash = hash('sha256', $password);
        $stmt = $this->db->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        return $stmt->execute([$name, $email, $hash]);
    }

    /**
     * Autentica o usuário e inicia a sessão.
     */
    public function login($email, $password) {
        $hash = hash('sha256', $password);
        $stmt = $this->db->prepare("SELECT id, name, email FROM users WHERE email = ? AND password = ?");
        $stmt->execute([$email, $hash]);
        $user = $stmt->fetch();

        if ($user) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            return true;
        }
        return false;
    }

    /**
     * Verifica se o usuário está autenticado.
     */
    public static function isAuthenticated() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return isset($_SESSION['user_id']);
    }

    /**
     * Finaliza a sessão do usuário.
     */
    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_destroy();
        return true;
    }
}
